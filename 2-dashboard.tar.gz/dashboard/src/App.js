import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_URL = process.env.REACT_APP_API_URL || '/api';

function App() {
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchStores();
    const interval = setInterval(fetchStores, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchStores = async () => {
    try {
      const response = await axios.get(`${API_URL}/stores`);
      setStores(response.data.stores);
      setLoading(false);
      setError(null);
    } catch (err) {
      console.error('Error fetching stores:', err);
      setError('Failed to fetch stores');
      setLoading(false);
    }
  };

  const createStore = async (type) => {
    setCreating(true);
    try {
      await axios.post(`${API_URL}/stores`, {
        type,
        userId: 'default-user'
      });
      fetchStores();
      setError(null);
    } catch (err) {
      console.error('Error creating store:', err);
      setError(err.response?.data?.message || 'Failed to create store');
    } finally {
      setCreating(false);
    }
  };

  const deleteStore = async (storeId) => {
    if (!window.confirm('Are you sure you want to delete this store?')) {
      return;
    }

    try {
      await axios.delete(`${API_URL}/stores/${storeId}`);
      fetchStores();
      setError(null);
    } catch (err) {
      console.error('Error deleting store:', err);
      setError(err.response?.data?.message || 'Failed to delete store');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ready': return '#10b981';
      case 'provisioning': return '#f59e0b';
      case 'failed': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  if (loading) {
    return (
      <div className="app">
        <div className="loading">Loading...</div>
      </div>
    );
  }

  return (
    <div className="app">
      <header className="header">
        <h1>🏪 Store Orchestrator Dashboard</h1>
        <p>Kubernetes-powered eCommerce store provisioning platform</p>
      </header>

      {error && (
        <div className="error-banner">
          {error}
          <button onClick={() => setError(null)}>×</button>
        </div>
      )}

      <div className="actions">
        <h2>Create New Store</h2>
        <div className="button-group">
          <button 
            className="btn btn-primary"
            onClick={() => createStore('woocommerce')}
            disabled={creating}
          >
            {creating ? 'Creating...' : '+ WooCommerce Store'}
          </button>
          <button 
            className="btn btn-secondary"
            onClick={() => createStore('medusa')}
            disabled={creating}
          >
            {creating ? 'Creating...' : '+ Medusa Store'}
          </button>
        </div>
      </div>

      <div className="stores-section">
        <h2>Your Stores ({stores.length})</h2>
        
        {stores.length === 0 ? (
          <div className="empty-state">
            <p>No stores yet. Create your first store above!</p>
          </div>
        ) : (
          <div className="stores-grid">
            {stores.map(store => (
              <div key={store.id} className="store-card">
                <div className="store-header">
                  <h3>{store.name}</h3>
                  <span 
                    className="status-badge"
                    style={{ backgroundColor: getStatusColor(store.status) }}
                  >
                    {store.status}
                  </span>
                </div>

                <div className="store-details">
                  <div className="detail-row">
                    <span className="label">Type:</span>
                    <span className="value">{store.type}</span>
                  </div>
                  <div className="detail-row">
                    <span className="label">ID:</span>
                    <span className="value">{store.id}</span>
                  </div>
                  <div className="detail-row">
                    <span className="label">Created:</span>
                    <span className="value">{formatDate(store.createdAt)}</span>
                  </div>
                  {store.url && (
                    <div className="detail-row">
                      <span className="label">URL:</span>
                      <a 
                        href={store.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="store-url"
                      >
                        {store.url}
                      </a>
                    </div>
                  )}
                  {store.error && (
                    <div className="error-message">
                      Error: {store.error}
                    </div>
                  )}
                </div>

                <div className="store-actions">
                  {store.status === 'ready' && store.url && (
                    <a 
                      href={store.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="btn btn-small btn-primary"
                    >
                      Open Store
                    </a>
                  )}
                  <button 
                    className="btn btn-small btn-danger"
                    onClick={() => deleteStore(store.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
