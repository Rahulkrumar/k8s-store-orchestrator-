const express = require('express');
const router = express.Router();

router.get('/liveness', (req, res) => {
  res.json({ status: 'alive' });
});

router.get('/readiness', (req, res) => {
  // Add checks for dependencies (k8s API, etc.)
  res.json({ status: 'ready' });
});

module.exports = router;
