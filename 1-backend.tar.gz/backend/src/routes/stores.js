const express = require('express');
const router = express.Router();
const storeOrchestrator = require('../services/store-orchestrator');
const logger = require('../utils/logger');

// List all stores
router.get('/', async (req, res) => {
  try {
    const userId = req.query.userId || null;
    const stores = await storeOrchestrator.listStores(userId);
    res.json({ stores });
  } catch (error) {
    logger.error('Error listing stores:', error);
    res.status(500).json({ error: 'Failed to list stores', message: error.message });
  }
});

// Get a specific store
router.get('/:id', async (req, res) => {
  try {
    const store = await storeOrchestrator.getStore(req.params.id);
    if (!store) {
      return res.status(404).json({ error: 'Store not found' });
    }
    res.json({ store });
  } catch (error) {
    logger.error('Error getting store:', error);
    res.status(500).json({ error: 'Failed to get store', message: error.message });
  }
});

// Create a new store
router.post('/', async (req, res) => {
  try {
    const { type, userId } = req.body;

    if (!type || !['woocommerce', 'medusa'].includes(type)) {
      return res.status(400).json({ 
        error: 'Invalid store type. Must be "woocommerce" or "medusa"' 
      });
    }

    const store = await storeOrchestrator.createStore(type, userId);
    res.status(202).json({ 
      store,
      message: 'Store provisioning started'
    });
  } catch (error) {
    logger.error('Error creating store:', error);
    res.status(500).json({ error: 'Failed to create store', message: error.message });
  }
});

// Delete a store
router.delete('/:id', async (req, res) => {
  try {
    await storeOrchestrator.deleteStore(req.params.id);
    res.json({ message: 'Store deleted successfully' });
  } catch (error) {
    logger.error('Error deleting store:', error);
    if (error.message === 'Store not found') {
      return res.status(404).json({ error: error.message });
    }
    res.status(500).json({ error: 'Failed to delete store', message: error.message });
  }
});

module.exports = router;
