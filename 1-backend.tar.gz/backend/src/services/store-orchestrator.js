const { v4: uuidv4 } = require('uuid');
const k8sClient = require('./k8s-client');
const helmService = require('./helm-service');
const logger = require('../utils/logger');

class StoreOrchestrator {
  constructor() {
    this.stores = new Map(); // In-memory store registry
    this.maxStoresPerUser = parseInt(process.env.MAX_STORES_PER_USER || '10');
    this.provisioningTimeout = parseInt(process.env.PROVISIONING_TIMEOUT || '600000'); // 10 minutes
  }

  async createStore(storeType, userId = 'default-user') {
    // Check user quota
    const userStores = Array.from(this.stores.values()).filter(s => s.userId === userId);
    if (userStores.length >= this.maxStoresPerUser) {
      throw new Error(`User has reached maximum store limit (${this.maxStoresPerUser})`);
    }

    const storeId = uuidv4().substring(0, 8);
    const storeName = `store-${storeId}`;
    const namespace = storeName;

    const store = {
      id: storeId,
      name: storeName,
      type: storeType,
      status: 'provisioning',
      namespace,
      userId,
      createdAt: new Date().toISOString(),
      url: null,
      error: null
    };

    this.stores.set(storeId, store);
    logger.info(`Creating store ${storeId} of type ${storeType}`);

    // Start provisioning asynchronously
    this.provisionStore(store).catch(error => {
      logger.error(`Failed to provision store ${storeId}:`, error);
      store.status = 'failed';
      store.error = error.message;
    });

    return store;
  }

  async provisionStore(store) {
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Provisioning timeout')), this.provisioningTimeout)
    );

    try {
      await Promise.race([
        this._doProvision(store),
        timeoutPromise
      ]);
    } catch (error) {
      store.status = 'failed';
      store.error = error.message;
      throw error;
    }
  }

  async _doProvision(store) {
    try {
      // 1. Create namespace with labels
      await k8sClient.createNamespace(store.namespace, {
        'store-id': store.id,
        'store-type': store.type,
        'user-id': store.userId
      });

      // 2. Create resource quota for the namespace
      await k8sClient.createResourceQuota(store.namespace, 'store-quota', {
        hard: {
          'requests.cpu': '2',
          'requests.memory': '4Gi',
          'limits.cpu': '4',
          'limits.memory': '8Gi',
          'persistentvolumeclaims': '5'
        }
      });

      // 3. Create limit range
      await k8sClient.createLimitRange(store.namespace, 'store-limits', {
        limits: [{
          type: 'Container',
          default: {
            cpu: '500m',
            memory: '512Mi'
          },
          defaultRequest: {
            cpu: '100m',
            memory: '128Mi'
          }
        }]
      });

      // 4. Generate secrets
      const dbPassword = this._generatePassword();
      await k8sClient.createSecret(store.namespace, 'db-credentials', {
        'mysql-root-password': dbPassword,
        'mysql-password': dbPassword
      });

      // 5. Deploy store using Helm-like manifests
      if (store.type === 'woocommerce') {
        await this._deployWooCommerce(store, dbPassword);
      } else if (store.type === 'medusa') {
        await this._deployMedusa(store, dbPassword);
      }

      // 6. Wait for deployment to be ready
      await this._waitForDeployment(store);

      // 7. Get the store URL
      store.url = this._getStoreUrl(store);
      store.status = 'ready';
      
      logger.info(`Store ${store.id} provisioned successfully at ${store.url}`);
    } catch (error) {
      logger.error(`Error provisioning store ${store.id}:`, error);
      throw error;
    }
  }

  async _deployWooCommerce(store, dbPassword) {
    const namespace = store.namespace;
    
    // Deploy MySQL
    await this._deployMySQL(namespace, dbPassword);
    
    // Deploy WordPress + WooCommerce
    await this._deployWordPress(namespace, dbPassword);
  }

  async _deployMedusa(store, dbPassword) {
    const namespace = store.namespace;
    
    // Deploy PostgreSQL
    await this._deployPostgreSQL(namespace, dbPassword);
    
    // Deploy Medusa backend
    await this._deployMedusaBackend(namespace, dbPassword);
    
    // Deploy Medusa storefront
    await this._deployMedusaStorefront(namespace);
  }

  async _deployMySQL(namespace, password) {
    // This would normally use kubectl apply or Helm
    // For now, we'll use the k8s client directly
    logger.info(`Deploying MySQL in namespace ${namespace}`);
    // Implementation would create StatefulSet, Service, PVC
  }

  async _deployWordPress(namespace, dbPassword) {
    logger.info(`Deploying WordPress in namespace ${namespace}`);
    // Implementation would create Deployment, Service, Ingress, PVC
  }

  async _deployPostgreSQL(namespace, password) {
    logger.info(`Deploying PostgreSQL in namespace ${namespace}`);
  }

  async _deployMedusaBackend(namespace, dbPassword) {
    logger.info(`Deploying Medusa backend in namespace ${namespace}`);
  }

  async _deployMedusaStorefront(namespace) {
    logger.info(`Deploying Medusa storefront in namespace ${namespace}`);
  }

  async _waitForDeployment(store, maxWaitTime = 300000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < maxWaitTime) {
      try {
        const pods = await k8sClient.listPodsInNamespace(store.namespace);
        
        const allReady = pods.every(pod => {
          const conditions = pod.status.conditions || [];
          return conditions.some(c => c.type === 'Ready' && c.status === 'True');
        });

        if (allReady && pods.length > 0) {
          logger.info(`All pods ready in namespace ${store.namespace}`);
          return true;
        }
      } catch (error) {
        logger.error(`Error checking pod status:`, error);
      }

      await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
    }

    throw new Error('Deployment readiness timeout');
  }

  _getStoreUrl(store) {
    const ingressDomain = process.env.INGRESS_DOMAIN || 'local.dev';
    return `http://${store.name}.${ingressDomain}`;
  }

  _generatePassword(length = 16) {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < length; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    return password;
  }

  async deleteStore(storeId) {
    const store = this.stores.get(storeId);
    if (!store) {
      throw new Error('Store not found');
    }

    logger.info(`Deleting store ${storeId}`);

    try {
      // Delete the namespace (this cascades to all resources)
      await k8sClient.deleteNamespace(store.namespace);
      
      // Remove from registry
      this.stores.delete(storeId);
      
      logger.info(`Store ${storeId} deleted successfully`);
      return true;
    } catch (error) {
      logger.error(`Error deleting store ${storeId}:`, error);
      throw error;
    }
  }

  async getStore(storeId) {
    const store = this.stores.get(storeId);
    if (!store) {
      return null;
    }

    // Update status by checking k8s resources
    try {
      const namespace = await k8sClient.getNamespace(store.namespace);
      if (!namespace && store.status !== 'failed') {
        store.status = 'failed';
        store.error = 'Namespace not found';
      }
    } catch (error) {
      logger.error(`Error getting store status:`, error);
    }

    return store;
  }

  async listStores(userId = null) {
    let stores = Array.from(this.stores.values());
    
    if (userId) {
      stores = stores.filter(s => s.userId === userId);
    }

    return stores;
  }

  // Idempotency: recover stores from k8s if orchestrator restarts
  async recoverStores() {
    logger.info('Recovering stores from Kubernetes...');
    
    try {
      const namespaces = await k8sClient.listNamespaces('app.kubernetes.io/managed-by=store-orchestrator');
      
      for (const ns of namespaces) {
        const labels = ns.metadata.labels || {};
        const storeId = labels['store-id'];
        
        if (storeId && !this.stores.has(storeId)) {
          const store = {
            id: storeId,
            name: ns.metadata.name,
            type: labels['store-type'] || 'unknown',
            status: 'ready', // Assume ready if namespace exists
            namespace: ns.metadata.name,
            userId: labels['user-id'] || 'default-user',
            createdAt: ns.metadata.creationTimestamp,
            url: this._getStoreUrl({ name: ns.metadata.name }),
            error: null
          };
          
          this.stores.set(storeId, store);
          logger.info(`Recovered store ${storeId}`);
        }
      }
      
      logger.info(`Recovered ${namespaces.length} stores`);
    } catch (error) {
      logger.error('Error recovering stores:', error);
    }
  }
}

module.exports = new StoreOrchestrator();
