const k8s = require('@kubernetes/client-node');
const logger = require('../utils/logger');

class KubernetesClient {
  constructor() {
    this.kc = new k8s.KubeConfig();
    
    // Load config based on environment
    if (process.env.KUBERNETES_SERVICE_HOST) {
      // Running inside cluster
      this.kc.loadFromCluster();
    } else {
      // Running outside cluster (development)
      this.kc.loadFromDefault();
    }

    this.k8sApi = this.kc.makeApiClient(k8s.CoreV1Api);
    this.appsApi = this.kc.makeApiClient(k8s.AppsV1Api);
    this.networkingApi = this.kc.makeApiClient(k8s.NetworkingV1Api);
    this.customApi = this.kc.makeApiClient(k8s.CustomObjectsApi);
  }

  async createNamespace(name, labels = {}) {
    const namespace = {
      metadata: {
        name,
        labels: {
          'app.kubernetes.io/managed-by': 'store-orchestrator',
          ...labels
        }
      }
    };

    try {
      const response = await this.k8sApi.createNamespace(namespace);
      logger.info(`Namespace ${name} created successfully`);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 409) {
        logger.info(`Namespace ${name} already exists`);
        return await this.getNamespace(name);
      }
      throw error;
    }
  }

  async getNamespace(name) {
    try {
      const response = await this.k8sApi.readNamespace(name);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 404) {
        return null;
      }
      throw error;
    }
  }

  async deleteNamespace(name) {
    try {
      await this.k8sApi.deleteNamespace(name);
      logger.info(`Namespace ${name} deleted successfully`);
      return true;
    } catch (error) {
      if (error.response?.statusCode === 404) {
        logger.info(`Namespace ${name} not found, skipping deletion`);
        return true;
      }
      throw error;
    }
  }

  async createSecret(namespace, name, data, type = 'Opaque') {
    const secret = {
      metadata: { name, namespace },
      type,
      stringData: data
    };

    try {
      const response = await this.k8sApi.createNamespacedSecret(namespace, secret);
      logger.info(`Secret ${name} created in namespace ${namespace}`);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 409) {
        logger.info(`Secret ${name} already exists in namespace ${namespace}`);
        return await this.getSecret(namespace, name);
      }
      throw error;
    }
  }

  async getSecret(namespace, name) {
    try {
      const response = await this.k8sApi.readNamespacedSecret(name, namespace);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 404) {
        return null;
      }
      throw error;
    }
  }

  async createConfigMap(namespace, name, data) {
    const configMap = {
      metadata: { name, namespace },
      data
    };

    try {
      const response = await this.k8sApi.createNamespacedConfigMap(namespace, configMap);
      logger.info(`ConfigMap ${name} created in namespace ${namespace}`);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 409) {
        logger.info(`ConfigMap ${name} already exists in namespace ${namespace}`);
        return await this.getConfigMap(namespace, name);
      }
      throw error;
    }
  }

  async getConfigMap(namespace, name) {
    try {
      const response = await this.k8sApi.readNamespacedConfigMap(name, namespace);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 404) {
        return null;
      }
      throw error;
    }
  }

  async listNamespaces(labelSelector) {
    try {
      const response = await this.k8sApi.listNamespace(
        undefined, undefined, undefined, undefined, labelSelector
      );
      return response.body.items;
    } catch (error) {
      throw error;
    }
  }

  async listPodsInNamespace(namespace) {
    try {
      const response = await this.k8sApi.listNamespacedPod(namespace);
      return response.body.items;
    } catch (error) {
      throw error;
    }
  }

  async listServicesInNamespace(namespace) {
    try {
      const response = await this.k8sApi.listNamespacedService(namespace);
      return response.body.items;
    } catch (error) {
      throw error;
    }
  }

  async createResourceQuota(namespace, name, spec) {
    const quota = {
      metadata: { name, namespace },
      spec
    };

    try {
      const response = await this.k8sApi.createNamespacedResourceQuota(namespace, quota);
      logger.info(`ResourceQuota ${name} created in namespace ${namespace}`);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 409) {
        logger.info(`ResourceQuota ${name} already exists`);
        return null;
      }
      throw error;
    }
  }

  async createLimitRange(namespace, name, spec) {
    const limitRange = {
      metadata: { name, namespace },
      spec
    };

    try {
      const response = await this.k8sApi.createNamespacedLimitRange(namespace, limitRange);
      logger.info(`LimitRange ${name} created in namespace ${namespace}`);
      return response.body;
    } catch (error) {
      if (error.response?.statusCode === 409) {
        logger.info(`LimitRange ${name} already exists`);
        return null;
      }
      throw error;
    }
  }
}

module.exports = new KubernetesClient();
