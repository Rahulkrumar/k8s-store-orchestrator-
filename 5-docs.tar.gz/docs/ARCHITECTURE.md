# System Design & Architecture

## Overview

The Store Orchestrator is a Kubernetes-native platform for provisioning and managing isolated eCommerce stores. It follows cloud-native best practices and is designed to run identically in local development and production environments.

## Design Principles

1. **Kubernetes-Native**: All store resources are Kubernetes objects
2. **Declarative Configuration**: Helm charts define desired state
3. **Namespace Isolation**: Each store in dedicated namespace
4. **Least Privilege**: RBAC with minimal necessary permissions
5. **Idempotent Operations**: Safe to retry any operation
6. **Fail-Safe**: Clean failure handling and rollback
7. **Observable**: Logging and status tracking throughout

## Component Architecture

### 1. Dashboard (Frontend)

**Technology**: React 18 + Axios

**Responsibilities**:
- User interface for store management
- Real-time status polling
- REST API client

**Scaling**:
- Stateless, can scale horizontally
- Served via NGINX
- HPA enabled in production (2-5 replicas)

**Security**:
- Runs as non-root user (UID 1001)
- Read-only root filesystem (where possible)
- All capabilities dropped

### 2. Backend API (Orchestrator)

**Technology**: Node.js + Express + Kubernetes Client

**Responsibilities**:
- REST API for store lifecycle (CRUD operations)
- Kubernetes resource orchestration
- State management and recovery
- Resource quota enforcement
- Audit logging

**Key Features**:
- Rate limiting (100 req/15min per IP)
- Store quota enforcement (10 per user default)
- Provisioning timeout (10 minutes)
- Concurrent provisioning support
- Idempotent operations

**Scaling**:
- Stateless API can scale horizontally
- In-memory store registry (would use Redis/DB in production)
- HPA enabled in production (2-5 replicas)

**Security**:
- Runs as non-root user (UID 1001)
- Uses ServiceAccount with RBAC
- Helmet.js security headers
- No hardcoded secrets

### 3. Kubernetes Resources

Each store provisions:

```
Store Namespace (store-xxxxx)
├── ResourceQuota (CPU, memory, PVC limits)
├── LimitRange (default resource requests/limits)
├── Secrets (database credentials)
├── StatefulSet (MySQL/PostgreSQL)
│   └── PersistentVolumeClaim (database data)
├── Deployment (WordPress/Medusa backend)
│   └── PersistentVolumeClaim (uploads, files)
├── Deployment (Storefront)
├── Services (ClusterIP)
└── Ingress (HTTP route)
```

## Data Flow

### Store Creation Flow

```
User clicks "Create Store"
    ↓
Dashboard → POST /api/stores {type: "woocommerce"}
    ↓
Backend validates request
    ↓
Backend checks user quota
    ↓
Backend generates unique store ID
    ↓
Backend creates store record (status: provisioning)
    ↓
Backend returns 202 Accepted
    ↓
Async: Backend starts provisioning
    ├─ Create namespace with labels
    ├─ Create ResourceQuota
    ├─ Create LimitRange
    ├─ Generate database password
    ├─ Create Secret for credentials
    ├─ Deploy database (StatefulSet + PVC)
    ├─ Deploy application (Deployment + PVC)
    ├─ Create Services
    ├─ Create Ingress
    ├─ Wait for pods to be ready
    └─ Update store status: ready
    ↓
Dashboard polls status every 5 seconds
    ↓
User sees "Ready" status and store URL
```

### Store Deletion Flow

```
User clicks "Delete"
    ↓
Dashboard → DELETE /api/stores/:id
    ↓
Backend deletes namespace
    ↓
Kubernetes cascades deletion:
    ├─ Deletes all Deployments
    ├─ Deletes all StatefulSets
    ├─ Deletes all Pods
    ├─ Deletes all Services
    ├─ Deletes all Ingresses
    ├─ Deletes all PVCs
    ├─ Deletes all Secrets
    └─ Deletes namespace
    ↓
Backend removes store from registry
    ↓
Backend returns success
```

## Isolation Strategy

### Namespace-Level Isolation

Each store gets a dedicated namespace named `store-{id}`. This provides:

- Resource isolation
- RBAC boundaries
- Network isolation (with NetworkPolicies)
- Secret isolation
- Clean deletion (delete namespace = delete all resources)

### Resource Quotas

Per-namespace quotas prevent resource exhaustion:

```yaml
hard:
  requests.cpu: 2
  requests.memory: 4Gi
  limits.cpu: 4
  limits.memory: 8Gi
  persistentvolumeclaims: 5
```

### LimitRanges

Default resource requests/limits for all containers:

```yaml
default:
  cpu: 500m
  memory: 512Mi
defaultRequest:
  cpu: 100m
  memory: 128Mi
```

### Network Policies (Optional)

Deny all traffic by default, allow only:
- Ingress from NGINX namespace
- Egress to DNS, external APIs
- Inter-pod communication within namespace

## Idempotency & Failure Handling

### Idempotent Operations

All Kubernetes resource creation is idempotent:

```javascript
try {
  await k8sClient.createNamespace(name);
} catch (error) {
  if (error.statusCode === 409) {
    // Namespace already exists, retrieve it
    return await k8sClient.getNamespace(name);
  }
  throw error;
}
```

This allows safe retries if provisioning fails mid-way.

### Recovery on Restart

When the orchestrator restarts, it:

1. Queries Kubernetes for all namespaces with label `app.kubernetes.io/managed-by=store-orchestrator`
2. Reconstructs store registry from namespace labels
3. Resumes management of existing stores

### Failure Modes

**Provisioning Timeout**:
- After 10 minutes, provisioning fails
- Store status set to 'failed'
- Error message stored
- Namespace remains (manual cleanup or auto-retry)

**Pod Crash During Provisioning**:
- Kubernetes restarts pod
- Recovery mechanism detects in-progress stores
- Resumes or marks failed

**API Server Unavailable**:
- Requests fail gracefully
- Retry with exponential backoff
- User sees error in dashboard

## Security Posture

### RBAC

ClusterRole permissions (least privilege):

```yaml
- apiGroups: [""]
  resources: [namespaces, pods, services, secrets, configmaps, pvcs, resourcequotas, limitranges]
  verbs: [get, list, watch, create, update, patch, delete]
- apiGroups: [apps]
  resources: [deployments, statefulsets]
  verbs: [get, list, watch, create, update, patch, delete]
- apiGroups: [networking.k8s.io]
  resources: [ingresses, networkpolicies]
  verbs: [get, list, watch, create, update, patch, delete]
```

### Secret Management

- Secrets generated at runtime (not in code)
- Stored in Kubernetes Secrets
- Never logged
- Encrypted at rest (K8s default)

### Container Security

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  fsGroup: 1001
  allowPrivilegeEscalation: false
  capabilities:
    drop: [ALL]
```

### API Security

- Helmet.js security headers
- CORS configured
- Rate limiting per IP
- Input validation

## Horizontal Scaling

### What Scales

**Dashboard**:
- Pure static files served by NGINX
- Scales to N replicas
- No state

**Backend API**:
- Stateless (store registry in-memory, would use Redis in prod)
- Scales to N replicas
- Load balanced by Service

**Store Instances**:
- Each in own namespace
- Independent scaling per store
- Orchestrator manages provisioning queue

### Scaling Strategy

```yaml
# Production HPA
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
spec:
  minReplicas: 2
  maxReplicas: 5
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        averageUtilization: 70%
```

### Concurrency Control

- Max provisioning concurrency: configurable (default: 5)
- Queue system for burst requests
- Per-user quotas prevent abuse

## Abuse Prevention

### Rate Limiting

```javascript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 100  // 100 requests per window
});
```

### Resource Quotas

**Per User**: Max 10 stores (configurable)

**Per Store**: 
- 2 CPU requests, 4 CPU limits
- 4 GB memory requests, 8 GB limits
- 5 PVCs max

### Timeouts

- Provisioning timeout: 10 minutes
- API request timeout: 30 seconds
- Pod readiness timeout: 5 minutes

### Audit Trail

All operations logged:

```json
{
  "timestamp": "2024-02-13T10:30:00Z",
  "action": "store.create",
  "userId": "user-123",
  "storeId": "abcd1234",
  "storeType": "woocommerce",
  "status": "success"
}
```

## Local vs Production Differences

### Handled via Helm Values

**Local (values.yaml)**:
```yaml
global:
  domain: local.dev
  storageClass: standard

backend:
  replicaCount: 1
  image:
    tag: latest
    pullPolicy: IfNotPresent

ingress:
  tls: []  # No TLS

autoscaling:
  enabled: false
```

**Production (values-prod.yaml)**:
```yaml
global:
  domain: yourdomain.com
  storageClass: do-block-storage

backend:
  replicaCount: 2
  image:
    tag: "1.0.0"
    pullPolicy: Always

ingress:
  tls:
    - secretName: orchestrator-tls
      hosts: [orchestrator.yourdomain.com]
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod

autoscaling:
  enabled: true
  minReplicas: 2
  maxReplicas: 5
```

### What Changes

| Component | Local | Production |
|-----------|-------|------------|
| Domain | local.dev | yourdomain.com |
| TLS | None | cert-manager + Let's Encrypt |
| Replicas | 1 | 2-5 (HPA) |
| Storage Class | standard | do-block-storage / gp2 |
| Image Registry | Local | DockerHub / ECR / GCR |
| Image Pull | IfNotPresent | Always |
| Resource Limits | Lower | Higher |
| Logging | Debug | Warn |

## Future Enhancements

### Short Term
- [ ] PostgreSQL support for WooCommerce
- [ ] Full Medusa implementation
- [ ] Redis for state persistence
- [ ] Prometheus metrics
- [ ] Grafana dashboards

### Medium Term
- [ ] Multi-user authentication
- [ ] Custom domain mapping
- [ ] Backup and restore
- [ ] Store cloning
- [ ] Template library

### Long Term
- [ ] Multi-cluster support
- [ ] GitOps deployment
- [ ] CI/CD pipeline integration
- [ ] Cost tracking per store
- [ ] AI-powered optimization

## Performance Metrics

### Target KPIs

- Store provisioning time: < 5 minutes (p95)
- API response time: < 200ms (p95)
- Dashboard load time: < 2 seconds
- Concurrent provisions: 10+
- Uptime: 99.9%

### Resource Usage

**Per Store**:
- CPU: 100m request, 500m limit
- Memory: 512Mi request, 2Gi limit
- Storage: 10Gi default

**Platform Components**:
- Backend: 100m CPU, 128Mi memory
- Dashboard: 50m CPU, 64Mi memory

## Testing Strategy

### Unit Tests
- Kubernetes client wrapper
- Store orchestrator logic
- API route handlers

### Integration Tests
- Full provisioning flow
- Store deletion cleanup
- Failure recovery

### E2E Tests
- Create WooCommerce store
- Place order end-to-end
- Delete store
- Verify cleanup

## Conclusion

This architecture provides a solid foundation for a production-grade store orchestration platform. It balances simplicity with scalability, security with usability, and local development with production deployment.

The use of Kubernetes-native resources and Helm charts ensures the system is portable, maintainable, and follows cloud-native best practices.
