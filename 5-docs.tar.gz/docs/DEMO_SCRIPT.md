# Demo Video Script

## Introduction (1-2 minutes)

**Show**: Architecture diagram

**Say**: 
"Hi! I'm demonstrating the Kubernetes Store Orchestrator - a platform for provisioning and managing isolated eCommerce stores on Kubernetes.

The system consists of:
- A React dashboard for the user interface
- A Node.js backend API for orchestration
- Kubernetes-native resources for store isolation
- Helm charts for deployment

Each store runs in its own namespace with resource quotas, persistent storage, and automatic cleanup."

## System Design & Implementation (3 minutes)

**Show**: Code walkthrough

**Say**:
"Let me walk through the key components:

1. **Backend Orchestrator** (show store-orchestrator.js):
   - Creates namespaces with labels for each store
   - Applies resource quotas and limit ranges
   - Generates secrets securely
   - Deploys databases and applications
   - Waits for readiness
   - Handles cleanup

2. **Kubernetes Client** (show k8s-client.js):
   - Wraps the Kubernetes API
   - All operations are idempotent
   - Safe to retry on failure

3. **Dashboard** (show App.js):
   - Real-time status updates via polling
   - Clean, user-friendly interface
   - Direct store access

4. **Helm Charts** (show templates/):
   - ServiceAccount with RBAC
   - Deployments with security contexts
   - Services and Ingress
   - HPA for production
   - Same charts for local and production"

## Live Demo - Store Creation (5 minutes)

**Show**: Terminal and browser side-by-side

**Say**: "Now let's see it in action."

### Terminal:
```bash
# Show cluster
kubectl get nodes

# Show namespaces (only system namespaces)
kubectl get ns

# Show orchestrator pods
kubectl get pods -n store-orchestrator
```

### Browser:
1. Open http://localhost:8080
2. Show empty dashboard
3. Click "Create New Store" → WooCommerce
4. **Say**: "The backend is now creating a namespace and deploying resources"

### Terminal (while provisioning):
```bash
# Watch namespaces being created
kubectl get ns -w

# In another terminal:
kubectl get pods -n store-xxxx -w

# Show resources being created
kubectl get all -n store-xxxx

# Show resource quota
kubectl get resourcequota -n store-xxxx -o yaml

# Show secrets (don't show values!)
kubectl get secrets -n store-xxxx
```

### Browser:
- Watch status change from "provisioning" to "ready"
- Click "Open Store"
- Show WooCommerce storefront

## End-to-End Test (3 minutes)

**Show**: Store and admin interface

**Say**: "Let's complete an order end-to-end."

### WooCommerce:
1. Browse to store
2. Add a product to cart
3. Go to checkout
4. Complete order with COD
5. **Say**: "Order placed!"

6. Go to admin (show how to access)
7. Navigate to WooCommerce → Orders
8. Show the order we just placed

**Say**: "This proves the store is fully functional."

## Store Deletion & Cleanup (2 minutes)

**Say**: "Now let's clean up."

### Browser:
1. Click "Delete" on the store
2. Confirm deletion

### Terminal:
```bash
# Watch namespace deletion
kubectl get ns -w

# Show namespace is being terminated
kubectl get ns | grep store-

# Wait for deletion to complete
# Show that namespace and all resources are gone
kubectl get all -n store-xxxx
# Error: namespace not found

# Show clean cluster
kubectl get ns
```

**Say**: "All resources have been cleaned up automatically - no orphaned resources."

## Isolation, Resources, Reliability (3 minutes)

**Show**: Code and terminal

**Say**: "Let me demonstrate the isolation and reliability features."

### Resource Isolation:
```bash
# Create another store to show multiple isolation
# Show both namespaces
kubectl get ns | grep store-

# Show resource quotas for each
kubectl describe resourcequota -n store-xxx1
kubectl describe resourcequota -n store-xxx2
```

**Say**: "Each store has its own quota - preventing resource exhaustion."

### Idempotency:
**Show**: Code in store-orchestrator.js

**Say**: 
"All operations are idempotent. If provisioning fails halfway:
- Namespace creation is idempotent (409 = already exists)
- Secret creation is idempotent
- The system can recover by checking existing resources

If the orchestrator crashes, it recovers by:
- Querying Kubernetes for managed namespaces
- Rebuilding the store registry from labels
- Resuming management"

### Failure Handling:
**Show**: Code showing timeout and error handling

**Say**:
"We have multiple safeguards:
- 10-minute provisioning timeout
- Pod readiness checks
- Graceful error handling
- Status tracking with error messages"

## Security Posture (3 minutes)

**Show**: Helm templates and manifests

**Say**: "Security is built in at every layer."

### RBAC:
```bash
# Show ClusterRole
kubectl get clusterrole orchestrator-orchestrator -o yaml
```

**Say**: "Least privilege - only the permissions needed."

### Security Contexts:
**Show**: Deployment templates

**Say**:
"All containers:
- Run as non-root user (UID 1001)
- Drop all capabilities
- No privilege escalation
- Read-only root filesystem where possible"

### Secret Management:
**Show**: Code generating secrets

**Say**:
"Secrets are:
- Generated at runtime (never in code)
- Stored in Kubernetes Secrets
- Never logged
- Unique per store"

### Network Security:
**Show**: NetworkPolicy example (optional)

**Say**:
"Optional NetworkPolicies provide:
- Deny all by default
- Allow only necessary ingress from NGINX
- Isolate stores from each other"

## Horizontal Scaling (2 minutes)

**Show**: values-prod.yaml

**Say**: "The platform is designed to scale."

### What Scales:
**Say**:
"Dashboard and Backend scale horizontally:
- Stateless components
- HPA configured for production
- 2-5 replicas based on CPU usage

Stores scale independently:
- Each in own namespace
- Can scale per-store resources
- Provisioning supports concurrency"

**Show**: HPA template

### Concurrency:
**Say**:
"The orchestrator handles concurrent provisioning:
- Multiple stores can be created simultaneously
- Queue system for burst requests
- Rate limiting prevents abuse"

## Abuse Prevention (2 minutes)

**Show**: Code and configuration

**Say**: "Multiple layers of abuse prevention."

### Rate Limiting:
**Show**: server.js rate limiter

**Say**: "100 requests per 15 minutes per IP"

### Quotas:
**Show**: Configuration

**Say**:
"Per user: Max 10 stores (configurable)
Per store: Resource quotas prevent resource exhaustion"

### Timeouts:
**Say**:
"Provisioning timeout: 10 minutes
API timeout: 30 seconds
Prevents stuck operations"

### Audit Trail:
**Show**: Logs

```bash
kubectl logs -n store-orchestrator deployment/orchestrator-backend
```

**Say**: "All operations are logged with user, action, and timestamp."

## Local-to-VPS Production Story (3 minutes)

**Show**: values.yaml and values-prod.yaml side-by-side

**Say**: "The same Helm charts work in both environments."

### What Changes:
**Say**:
"Via Helm values only:
- Domain: local.dev → yourdomain.com
- Storage class: standard → do-block-storage
- TLS: none → cert-manager + Let's Encrypt
- Replicas: 1 → 2-5 with HPA
- Image registry: local → DockerHub/ECR
- Resource limits: lower → higher
- Logging level: debug → warn"

### Deployment:
**Show**: deploy-prod.sh

**Say**:
"Production deployment:
1. Install k3s on VPS
2. Configure DNS
3. Run deploy script
4. Helm installs with production values
5. cert-manager issues TLS certificate
6. Ready to go!"

**Show**: Example production deployment (if possible)

### Upgrade/Rollback:
**Show**: Commands

```bash
# Upgrade
helm upgrade orchestrator ./chart --values values-prod.yaml

# Rollback
helm rollback orchestrator

# History
helm history orchestrator
```

**Say**: "Helm provides safe upgrade and rollback capabilities."

## Conclusion (1 minute)

**Say**:
"To summarize, this platform provides:

✅ Kubernetes-native store orchestration
✅ Namespace-level isolation with quotas
✅ Idempotent operations and failure recovery
✅ Security hardening and RBAC
✅ Horizontal scaling capabilities
✅ Abuse prevention at multiple layers
✅ Identical local and production deployment
✅ Clean upgrade and rollback story

The code is production-ready, well-documented, and follows cloud-native best practices.

Thank you for watching!"

---

## Recording Tips

1. **Preparation**:
   - Have cluster ready
   - Test run everything
   - Prepare terminal windows
   - Clean up previous tests

2. **Screen Layout**:
   - Browser on left
   - Terminal(s) on right
   - Use zoom for code snippets

3. **Pacing**:
   - Speak clearly and steadily
   - Pause after showing complex code
   - Use terminal commands to emphasize points
   - Don't rush through failures/timeouts

4. **Technical**:
   - Use screen recording software (OBS, QuickTime, etc.)
   - Record in 1080p minimum
   - Test audio levels
   - Use a good microphone

5. **Engagement**:
   - Show enthusiasm
   - Explain WHY not just WHAT
   - Point out design decisions
   - Highlight production-readiness aspects
