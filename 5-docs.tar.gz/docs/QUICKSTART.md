# Quick Start Guide

## Prerequisites Installation

### macOS
```bash
# Install Homebrew (if not already installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install prerequisites
brew install docker kubectl helm kind

# Start Docker Desktop
open -a Docker
```

### Linux
```bash
# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker

# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Install Helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Install Kind
curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.20.0/kind-linux-amd64
chmod +x ./kind
sudo mv ./kind /usr/local/bin/kind
```

### Windows (WSL2)
```bash
# Follow Linux instructions above in WSL2
# Make sure Docker Desktop is installed and WSL2 integration is enabled
```

## Setup in 3 Commands

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/k8s-store-orchestrator.git
cd k8s-store-orchestrator

# 2. Run setup script
./scripts/setup-local.sh

# 3. Port forward and access
kubectl port-forward -n store-orchestrator svc/orchestrator-dashboard 8080:80
```

Then open http://localhost:8080

## Common Tasks

### View All Resources
```bash
kubectl get all -n store-orchestrator
```

### View Logs
```bash
# Backend logs
kubectl logs -n store-orchestrator deployment/orchestrator-backend -f

# Dashboard logs
kubectl logs -n store-orchestrator deployment/orchestrator-dashboard -f
```

### Check Store Status
```bash
# List all store namespaces
kubectl get ns -l app.kubernetes.io/managed-by=store-orchestrator

# View specific store resources
kubectl get all -n store-xxxxx
```

### Restart Components
```bash
# Restart backend
kubectl rollout restart deployment/orchestrator-backend -n store-orchestrator

# Restart dashboard
kubectl rollout restart deployment/orchestrator-dashboard -n store-orchestrator
```

### Delete Everything
```bash
# Delete the Helm release
helm uninstall orchestrator -n store-orchestrator

# Delete the namespace
kubectl delete namespace store-orchestrator

# Delete all store namespaces
kubectl delete ns -l app.kubernetes.io/managed-by=store-orchestrator

# Delete the cluster
kind delete cluster --name store-orchestrator
```

## Troubleshooting

### Pods not starting?
```bash
# Check pod status
kubectl get pods -n store-orchestrator

# Describe pod for events
kubectl describe pod <pod-name> -n store-orchestrator

# Check logs
kubectl logs <pod-name> -n store-orchestrator
```

### Images not pulling?
```bash
# For Kind, load images manually
kind load docker-image store-orchestrator-backend:latest --name store-orchestrator
kind load docker-image store-orchestrator-dashboard:latest --name store-orchestrator
```

### Ingress not working?
```bash
# Check ingress controller
kubectl get pods -n ingress-nginx

# Check ingress resource
kubectl get ingress -n store-orchestrator
kubectl describe ingress orchestrator-ingress -n store-orchestrator

# Use port-forward as workaround
kubectl port-forward -n store-orchestrator svc/orchestrator-dashboard 8080:80
```

### Store stuck in "Provisioning"?
```bash
# Check store namespace pods
kubectl get pods -n store-xxxxx

# Check backend logs
kubectl logs -n store-orchestrator deployment/orchestrator-backend -f

# Manually delete stuck store namespace
kubectl delete ns store-xxxxx
```

## Development Workflow

### Make Code Changes

```bash
# 1. Edit code in backend/ or dashboard/

# 2. Rebuild images
docker build -t store-orchestrator-backend:latest ./backend
docker build -t store-orchestrator-dashboard:latest ./dashboard

# 3. Load into Kind
kind load docker-image store-orchestrator-backend:latest --name store-orchestrator
kind load docker-image store-orchestrator-dashboard:latest --name store-orchestrator

# 4. Restart deployments
kubectl rollout restart deployment -n store-orchestrator
```

### Update Helm Chart

```bash
# After editing Helm templates or values
helm upgrade orchestrator ./helm/store-orchestrator \
  --namespace store-orchestrator \
  --values ./helm/store-orchestrator/values.yaml
```

## Testing Checklist

- [ ] Dashboard loads successfully
- [ ] Create WooCommerce store
- [ ] Store status changes to "Ready"
- [ ] Store URL works
- [ ] Can place order end-to-end
- [ ] Delete store
- [ ] Namespace and resources cleaned up
- [ ] Create Medusa store (if implemented)
- [ ] Test concurrent store creation
- [ ] Test quota enforcement (create 11th store)
- [ ] Test rate limiting (spam create button)

## Production Deployment

See full production guide in README.md, but in short:

```bash
# 1. Set environment variables
export DOMAIN=yourdomain.com
export REGISTRY=your-docker-registry
export EMAIL=your-email@example.com

# 2. Build and push images
docker build -t $REGISTRY/store-orchestrator-backend:1.0.0 ./backend
docker build -t $REGISTRY/store-orchestrator-dashboard:1.0.0 ./dashboard
docker push $REGISTRY/store-orchestrator-backend:1.0.0
docker push $REGISTRY/store-orchestrator-dashboard:1.0.0

# 3. Deploy to k3s
./scripts/deploy-prod.sh
```

## Useful Commands Reference

```bash
# Get everything in namespace
kubectl get all -n <namespace>

# Watch resources
kubectl get pods -n <namespace> -w

# Port forward
kubectl port-forward -n <namespace> svc/<service> <local-port>:<service-port>

# Execute into pod
kubectl exec -it -n <namespace> <pod-name> -- /bin/sh

# Copy files from pod
kubectl cp <namespace>/<pod-name>:/path/to/file ./local/file

# View events
kubectl get events -n <namespace> --sort-by='.lastTimestamp'

# Resource usage
kubectl top nodes
kubectl top pods -n <namespace>

# Helm commands
helm list -n <namespace>
helm status <release> -n <namespace>
helm history <release> -n <namespace>
helm rollback <release> <revision> -n <namespace>
```

## Next Steps

1. Read the full [README.md](../README.md)
2. Study the [Architecture Document](./ARCHITECTURE.md)
3. Review the [Demo Script](./DEMO_SCRIPT.md)
4. Experiment with the system
5. Implement additional features
6. Deploy to production

## Getting Help

- Check logs: `kubectl logs -n store-orchestrator deployment/orchestrator-backend`
- Review Kubernetes events: `kubectl get events -n <namespace>`
- Describe resources: `kubectl describe <resource> <name> -n <namespace>`
- Check pod status: `kubectl get pods -n <namespace> -o wide`

Happy orchestrating! 🚀
