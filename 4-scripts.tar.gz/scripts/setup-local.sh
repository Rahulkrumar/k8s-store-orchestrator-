#!/bin/bash

set -e

echo "🚀 Setting up Kubernetes Store Orchestrator locally..."

# Check prerequisites
command -v docker >/dev/null 2>&1 || { echo "❌ Docker is required but not installed."; exit 1; }
command -v kubectl >/dev/null 2>&1 || { echo "❌ kubectl is required but not installed."; exit 1; }
command -v helm >/dev/null 2>&1 || { echo "❌ Helm is required but not installed."; exit 1; }

# Check if kind is available
if command -v kind >/dev/null 2>&1; then
    CLUSTER_TOOL="kind"
    CLUSTER_NAME="store-orchestrator"
elif command -v k3d >/dev/null 2>&1; then
    CLUSTER_TOOL="k3d"
    CLUSTER_NAME="store-orchestrator"
elif command -v minikube >/dev/null 2>&1; then
    CLUSTER_TOOL="minikube"
    CLUSTER_NAME="store-orchestrator"
else
    echo "❌ No Kubernetes cluster tool found. Please install kind, k3d, or minikube."
    exit 1
fi

echo "✅ Using $CLUSTER_TOOL for local cluster"

# Create cluster
echo "📦 Creating Kubernetes cluster..."
if [ "$CLUSTER_TOOL" = "kind" ]; then
    kind create cluster --name $CLUSTER_NAME || echo "Cluster already exists"
elif [ "$CLUSTER_TOOL" = "k3d" ]; then
    k3d cluster create $CLUSTER_NAME || echo "Cluster already exists"
elif [ "$CLUSTER_TOOL" = "minikube" ]; then
    minikube start --profile $CLUSTER_NAME || echo "Cluster already exists"
fi

# Set kubectl context
if [ "$CLUSTER_TOOL" = "kind" ]; then
    kubectl config use-context kind-$CLUSTER_NAME
elif [ "$CLUSTER_TOOL" = "k3d" ]; then
    kubectl config use-context k3d-$CLUSTER_NAME
elif [ "$CLUSTER_TOOL" = "minikube" ]; then
    kubectl config use-context $CLUSTER_NAME
fi

# Install NGINX Ingress Controller
echo "🌐 Installing NGINX Ingress Controller..."
if [ "$CLUSTER_TOOL" = "kind" ]; then
    kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
elif [ "$CLUSTER_TOOL" = "minikube" ]; then
    minikube addons enable ingress --profile $CLUSTER_NAME
else
    kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml
fi

echo "⏳ Waiting for ingress controller to be ready..."
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=120s || echo "Timeout waiting for ingress controller (might still be starting)"

# Build Docker images
echo "🏗️  Building Docker images..."
echo "Building backend..."
docker build -t store-orchestrator-backend:latest ./backend

echo "Building dashboard..."
docker build -t store-orchestrator-dashboard:latest ./dashboard

# Load images into cluster
if [ "$CLUSTER_TOOL" = "kind" ]; then
    echo "📥 Loading images into Kind cluster..."
    kind load docker-image store-orchestrator-backend:latest --name $CLUSTER_NAME
    kind load docker-image store-orchestrator-dashboard:latest --name $CLUSTER_NAME
elif [ "$CLUSTER_TOOL" = "minikube" ]; then
    echo "📥 Loading images into Minikube..."
    minikube image load store-orchestrator-backend:latest --profile $CLUSTER_NAME
    minikube image load store-orchestrator-dashboard:latest --profile $CLUSTER_NAME
fi

# Create namespace
echo "📁 Creating namespace..."
kubectl create namespace store-orchestrator || echo "Namespace already exists"

# Install Helm chart
echo "📦 Installing Helm chart..."
helm upgrade --install orchestrator ./helm/store-orchestrator \
  --namespace store-orchestrator \
  --values ./helm/store-orchestrator/values.yaml

echo "⏳ Waiting for deployments to be ready..."
kubectl wait --namespace store-orchestrator \
  --for=condition=available deployment \
  --all \
  --timeout=180s || echo "Timeout waiting for deployments (might still be starting)"

# Get service URLs
echo ""
echo "✅ Setup complete!"
echo ""
echo "📝 Next steps:"
echo ""
echo "1. Add to /etc/hosts:"
echo "   127.0.0.1  orchestrator.local.dev"
echo ""
echo "2. Port forward the dashboard:"
echo "   kubectl port-forward -n store-orchestrator svc/orchestrator-dashboard 8080:80"
echo ""
echo "3. Access the dashboard:"
echo "   http://localhost:8080"
echo ""
echo "4. View logs:"
echo "   kubectl logs -n store-orchestrator deployment/orchestrator-backend -f"
echo ""
echo "5. Check status:"
echo "   kubectl get pods -n store-orchestrator"
echo ""
