#!/bin/bash

set -e

echo "🚀 Deploying Store Orchestrator to Production (k3s)..."

# Check prerequisites
command -v kubectl >/dev/null 2>&1 || { echo "❌ kubectl is required but not installed."; exit 1; }
command -v helm >/dev/null 2>&1 || { echo "❌ Helm is required but not installed."; exit 1; }

# Check if k3s is running
kubectl get nodes >/dev/null 2>&1 || { echo "❌ Cannot connect to Kubernetes cluster. Is k3s running?"; exit 1; }

echo "✅ Connected to Kubernetes cluster"

# Configuration
DOMAIN=${DOMAIN:-"yourdomain.com"}
REGISTRY=${REGISTRY:-"your-registry"}
VERSION=${VERSION:-"1.0.0"}
EMAIL=${EMAIL:-"your-email@example.com"}

echo "📋 Configuration:"
echo "   Domain: $DOMAIN"
echo "   Registry: $REGISTRY"
echo "   Version: $VERSION"
echo "   Email: $EMAIL"
echo ""

read -p "Continue with these settings? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
fi

# Update values-prod.yaml with domain
echo "📝 Updating production values..."
sed -i "s/yourdomain.com/$DOMAIN/g" ./helm/store-orchestrator/values-prod.yaml
sed -i "s/your-registry/$REGISTRY/g" ./helm/store-orchestrator/values-prod.yaml
sed -i "s/your-email@example.com/$EMAIL/g" ./helm/store-orchestrator/values-prod.yaml

# Install cert-manager if not already installed
if ! kubectl get namespace cert-manager >/dev/null 2>&1; then
    echo "📦 Installing cert-manager..."
    kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml
    
    echo "⏳ Waiting for cert-manager to be ready..."
    kubectl wait --namespace cert-manager \
      --for=condition=available deployment \
      --all \
      --timeout=120s
fi

# Create Let's Encrypt ClusterIssuer
echo "🔐 Creating Let's Encrypt issuer..."
cat <<EOF | kubectl apply -f -
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: $EMAIL
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
EOF

# Create namespace
echo "📁 Creating namespace..."
kubectl create namespace store-orchestrator || echo "Namespace already exists"

# Install/upgrade Helm chart
echo "📦 Deploying with Helm..."
helm upgrade --install orchestrator ./helm/store-orchestrator \
  --namespace store-orchestrator \
  --values ./helm/store-orchestrator/values-prod.yaml \
  --set backend.image.tag=$VERSION \
  --set dashboard.image.tag=$VERSION \
  --wait \
  --timeout 10m

echo "⏳ Waiting for deployments to be ready..."
kubectl wait --namespace store-orchestrator \
  --for=condition=available deployment \
  --all \
  --timeout=300s

# Get ingress IP
INGRESS_IP=$(kubectl get svc -n ingress-nginx ingress-nginx-controller -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

if [ -z "$INGRESS_IP" ]; then
    INGRESS_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}')
fi

echo ""
echo "✅ Deployment complete!"
echo ""
echo "📝 Next steps:"
echo ""
echo "1. Configure DNS A records:"
echo "   orchestrator.$DOMAIN  →  $INGRESS_IP"
echo "   *.$DOMAIN             →  $INGRESS_IP"
echo ""
echo "2. Wait for TLS certificate to be issued (1-2 minutes)"
echo "   kubectl get certificate -n store-orchestrator"
echo ""
echo "3. Access the dashboard:"
echo "   https://orchestrator.$DOMAIN"
echo ""
echo "4. Monitor the deployment:"
echo "   kubectl get pods -n store-orchestrator -w"
echo ""
echo "5. View logs:"
echo "   kubectl logs -n store-orchestrator deployment/orchestrator-backend -f"
echo ""
